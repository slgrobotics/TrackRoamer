using System;
using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Ccr.Core;
using Microsoft.Dss.Core.Attributes;
using Microsoft.Dss.ServiceModel.Dssp;
using Microsoft.Dss.ServiceModel.DsspServiceBase;
using W3C.Soap;
using submgr = Microsoft.Dss.Services.SubscriptionManager;
using gps = Microsoft.Robotics.Services.Sensors.Gps.Proxy;
using chrum6orientationsensor = TrackRoamer.Robotics.Hardware.ChrUm6OrientationSensor.Proxy;

namespace TrackRoamer.Robotics.Services.TrackroamerLocationAndMapping
{
    [Contract(Contract.Identifier)]
    [DisplayName("TrackroamerLocationAndMapping")]
    [Description("TrackroamerLocationAndMapping service (no description provided)")]
    class TrackroamerLocationAndMappingService : DsspServiceBase
    {
        /// <summary>
        /// Service state
        /// </summary>
        [ServiceState]
        TrackroamerLocationAndMappingState _state = new TrackroamerLocationAndMappingState();

        /// <summary>
        /// Main service port
        /// </summary>
        [ServicePort("/TrackroamerLocationAndMapping", AllowMultipleInstances = true)]
        TrackroamerLocationAndMappingOperations _mainPort = new TrackroamerLocationAndMappingOperations();

        [SubscriptionManagerPartner]
        submgr.SubscriptionManagerPort _submgrPort = new submgr.SubscriptionManagerPort();

        /// <summary>
        /// MicrosoftGpsService partner
        /// </summary>
        [Partner("MicrosoftGpsService", Contract = gps.Contract.Identifier, CreationPolicy = PartnerCreationPolicy.UseExistingOrCreate)]
        gps.MicrosoftGpsOperations _microsoftGpsServicePort = new gps.MicrosoftGpsOperations();
        gps.MicrosoftGpsOperations _microsoftGpsServiceNotify = new gps.MicrosoftGpsOperations();

        /// <summary>
        /// ChrUm6OrientationSensorService partner
        /// </summary>
        [Partner("ChrUm6OrientationSensorService", Contract = chrum6orientationsensor.Contract.Identifier, CreationPolicy = PartnerCreationPolicy.UseExistingOrCreate)]
        chrum6orientationsensor.ChrUm6OrientationSensorOperations _chrUm6OrientationSensorServicePort = new chrum6orientationsensor.ChrUm6OrientationSensorOperations();
        chrum6orientationsensor.ChrUm6OrientationSensorOperations _chrUm6OrientationSensorServiceNotify = new chrum6orientationsensor.ChrUm6OrientationSensorOperations();

        /// <summary>
        /// Service constructor
        /// </summary>
        public TrackroamerLocationAndMappingService(DsspServiceCreationPort creationPort)
            : base(creationPort)
        {
        }

        /// <summary>
        /// Service start
        /// </summary>
        protected override void Start()
        {

            // 
            // Add service specific initialization here
            // 

            base.Start();
        }

        /// <summary>
        /// Handles Subscribe messages
        /// </summary>
        /// <param name="subscribe">the subscribe request</param>
        [ServiceHandler]
        public void SubscribeHandler(Subscribe subscribe)
        {
            SubscribeHelper(_submgrPort, subscribe.Body, subscribe.ResponsePort);
        }
    }
}


