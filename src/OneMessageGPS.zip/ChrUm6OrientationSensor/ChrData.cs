﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

using W3C.Soap;

using Microsoft.Dss.Core.Attributes;
using Microsoft.Dss.ServiceModel.Dssp;

namespace TrackRoamer.Robotics.Hardware.ChrUm6OrientationSensor
{
    public class ChrQuaternion
    {
        public double a;
        public double b;
        public double c;
        public double d;
    }

    #region Chr State Type
    /// <summary>
    /// CH Robotics UM6 Orientation Sensor State
    /// </summary>
    [DataContract]
    [Description("The CHR UM6 Orientation Sensor state")]
    public class ChrUm6OrientationSensorState
    {
        #region Private data members
        private bool _connected;
        private ChrUm6OrientationSensorConfig _chrConfig;
        private GpRmc _gpRmc;
        #endregion

        /// <summary>
        /// Is the Chr unit currently connected.
        /// </summary>
        [DataMember]
        [Description("Indicates that the CHR UM6 Sensor is connected.")]
        [Browsable(false)]
        public bool Connected
        {
            get { return _connected; }
            set { _connected = value; }
        }

        /// <summary>
        /// Serial Port Configuration
        /// </summary>
        [DataMember(IsRequired = true)]
        [Description("Specifies the serial port where the CHR UM6 Sensor is connected.")]
        public ChrUm6OrientationSensorConfig ChrUm6OrientationSensorConfig
        {
            get
            {
                return this._chrConfig;
            }
            set
            {
                this._chrConfig = value;
            }
        }

        /// <summary>
        /// Backup course, speed, and position
        /// </summary>
        [DataMember(IsRequired = false)]
        [Browsable(false)]
        [Description("Indicates the time, date, position, course and speed data.")]
        public GpRmc GpRmc
        {
            get
            {
                return this._gpRmc;
            }
            set
            {
                this._gpRmc = value;
            }
        }
    }

    #endregion

    #region Chr Configuration

    /// <summary>
    /// ChrUm6OrientationSensor Serial Port Configuration
    /// </summary>
    [DataContract]
    [DisplayName("(User) ChrUm6OrientationSensor Configuration")]
    [Description("ChrUm6OrientationSensor Serial Port Configuration")]
    public class ChrUm6OrientationSensorConfig : ICloneable
    {
        #region Private data members
        private int _commPort;
        private string _portName;
        private int _baudRate;
        private string _configurationStatus;
        #endregion

        /// <summary>
        /// The Serial Comm Port
        /// </summary>
        [DataMember]
        [Description("Chr COM Port")]
        public int CommPort
        {
            get { return this._commPort; }
            set { this._commPort = value; }
        }

        /// <summary>
        /// The Serial Port Name or the File name containing Chr readings
        /// </summary>
        [DataMember]
        [Description("The Serial Port Name or the File name containing Chr readings (Default blank)")]
        public string PortName
        {
            get { return this._portName; }
            set { this._portName = value; }
        }

        /// <summary>
        /// Baud Rate
        /// </summary>
        [DataMember]
        [Description("Chr Baud Rate")]
        public int BaudRate
        {
            get { return this._baudRate; }
            set { this._baudRate = value; }
        }

        /// <summary>
        /// Configuration Status
        /// </summary>
        [DataMember]
        [Browsable(false)]
        [Description("Chr Configuration Status")]
        public string ConfigurationStatus
        {
            get { return _configurationStatus; }
            set { _configurationStatus = value; }
        }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ChrUm6OrientationSensorConfig()
        {
            this.BaudRate = 115200;
            this.CommPort = 0;
            this.PortName = string.Empty;
        }

        #region ICloneable Members

        /// <summary>
        /// Clone ChrUm6OrientationSensorConfig
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {

            ChrUm6OrientationSensorConfig config = new ChrUm6OrientationSensorConfig();
            config.BaudRate = this.BaudRate;
            config.CommPort = this.CommPort;
            config.PortName = this.PortName;
            return config;
        }

        #endregion
    }

    /// <summary>
    /// A CHR UM6 Sensor Command
    /// <remarks>Use with SendChrUm6OrientationSensorCommand()</remarks>
    /// </summary>
    [DataContract]
    [Description("A CHR UM6 Sensor Command")]
    public class ChrUm6OrientationSensorCommand
    {
        private string _command;

        /// <summary>
        /// Command
        /// </summary>
        [DataMember]
        public string Command
        {
            get
            {
                return this._command;
            }
            set
            {
                this._command = value;
            }
        }
    }

    /// <summary>
    /// standard subscribe request type
    /// </summary>
    [DataContract]
    [Description("Standard Subscribe request")]
    public class SubscribeRequest : SubscribeRequestType
    {
        /// <summary>
        /// Which message types to subscribe to
        /// </summary>
        [DataMember]
        public ChrMessageType MessageTypes;

        /// <summary>
        /// Only subscribe to messages when IsValid is true
        /// </summary>
        [DataMember]
        public bool ValidOnly;
    }

    #endregion

    #region Chr Data Structures

    /// <summary>
    /// Time, date, position, course and speed data
    /// </summary>
    [DataContract]
    [Description("Indicates the time, date, position, course and speed data.")]
    public class GpRmc
    {
        #region Private Members
        private bool _isValid;
        private System.DateTime _lastUpdate;
        private System.DateTime _dateTime;
        private string _status;
        private double _latitude;
        private double _longitude;
        private double _speedMetersPerSecond;
        private double _courseDegrees;
        #endregion

        /// <summary>
        /// Rmc Is Valid
        /// </summary>
        [DataMember]
        [Description("Indicates the RMC is valid.")]
        public bool IsValid
        {
            get
            {
                return this._isValid;
            }
            set
            {
                this._isValid = value;
            }
        }

        /// <summary>
        /// Rmc Last Update
        /// </summary>
        [DataMember]
        [Description("Indicates the time of the last reading update.")]
        public System.DateTime LastUpdate
        {
            get
            {
                return this._lastUpdate;
            }
            set
            {
                this._lastUpdate = value;
            }
        }

        /// <summary>
        /// Rmc Date Time
        /// </summary>
        [DataMember]
        [Description("Indicates the RMC time.")]
        public System.DateTime DateTime
        {
            get
            {
                return this._dateTime;
            }
            set
            {
                this._dateTime = value;
            }
        }
        /// <summary>
        /// Rmc Status
        /// </summary>
        [DataMember]
        [Description("Indicates the RMC status.")]
        public string Status
        {
            get
            {
                return this._status;
            }
            set
            {
                this._status = value;
            }
        }
        /// <summary>
        /// Rmc Latitude
        /// </summary>
        [DataMember]
        [Description("Indicates the latitude.")]
        public double Latitude
        {
            get
            {
                return this._latitude;
            }
            set
            {
                this._latitude = value;
            }
        }
        /// <summary>
        /// Rmc Longitude
        /// </summary>
        [DataMember]
        [Description("Indicates the longitude.")]
        public double Longitude
        {
            get
            {
                return this._longitude;
            }
            set
            {
                this._longitude = value;
            }
        }
        /// <summary>
        /// Rmc Speed Meters Per Second
        /// </summary>
        [DataMember]
        [Description("Indicates the RMC speed (meters per second).")]
        public double SpeedMetersPerSecond
        {
            get
            {
                return this._speedMetersPerSecond;
            }
            set
            {
                this._speedMetersPerSecond = value;
            }
        }
        /// <summary>
        /// Rmc Course Degrees
        /// </summary>
        [DataMember]
        [Description("Indicates the RMC course degrees.")]
        public double CourseDegrees
        {
            get
            {
                return this._courseDegrees;
            }
            set
            {
                this._courseDegrees = value;
            }
        }
    }
    #endregion

    #region Chr Enums

    /// <summary>
    /// Position Fix Indicator
    /// </summary>
    [DataContract]
    [Description("Identifies the Position Fix Indicator settings.")]
    public enum PositionFixIndicator
    {
        /// <summary>
        /// Fix Not Available
        /// </summary>
        [DataMember]
        FixNotAvailable = 0,
        /// <summary>
        /// ChrSPS Mode
        /// </summary>
        [DataMember]
        ChrSPSMode = 1,
        /// <summary>
        /// Differential ChrSPS Mode
        /// </summary>
        [DataMember]
        DifferentialChrSPSMode = 2,
        /// <summary>
        /// ChrPPS Mode
        /// </summary>
        [DataMember]
        ChrPPSMode = 3,
    }

    /// <summary>
    /// Chr Message Type
    /// </summary>
    [DataContract, Flags]
    [Description("Identifies the NMEA message types.")]
    public enum ChrMessageType
    {
        /// <summary>
        /// No message
        /// </summary>
        None = 0,

        /// <summary>
        /// Backup course, speed, and position
        /// </summary>
        GPRMC = 0x10,

        /// <summary>
        /// All message types
        /// </summary>
        All = GPRMC         // use "|" to combine all types here
    }

    #endregion

}

