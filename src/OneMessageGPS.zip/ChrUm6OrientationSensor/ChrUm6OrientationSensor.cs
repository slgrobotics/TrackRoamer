using System;
using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Ccr.Core;
using Microsoft.Dss.Core.Attributes;
using Microsoft.Dss.ServiceModel.Dssp;
using Microsoft.Dss.ServiceModel.DsspServiceBase;
using W3C.Soap;
using submgr = Microsoft.Dss.Services.SubscriptionManager;

using System.Collections.Specialized;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Mime;
using System.Security.Permissions;

using Microsoft.Dss.Core;
using Microsoft.Dss.Core.DsspHttp;
using Microsoft.Dss.Core.DsspHttpUtilities;

using TrackRoamer.Robotics.Hardware.ChrUm6OrientationSensor.Properties;

namespace TrackRoamer.Robotics.Hardware.ChrUm6OrientationSensor
{
    [Contract(Contract.Identifier)]
    [DisplayName("(User) ChrUm6OrientationSensor")]
    [Description("Provides Data from CH Robotics UM6 Orientation Sensor")]
    class ChrUm6OrientationSensorService : DsspServiceBase
    {
        [EmbeddedResource("TrackRoamer.Robotics.Hardware.ChrUm6OrientationSensor.ChrUm6OrientationSensor.user.xslt")]
        private string _transformChrData = null;

        private const string _configFile = ServicePaths.Store + "/ChrUm6OrientationSensor.config.xml";

        const string Tag_GpRmc = "GPRMC";

        /// <summary>
        /// Service state
        /// </summary>
        [ServiceState]
        [InitialStatePartner(Optional = true, ServiceUri = _configFile)]
        private ChrUm6OrientationSensorState _state = new ChrUm6OrientationSensorState();

        /// <summary>
        /// Main service port
        /// </summary>
        [ServicePort("/ChrUm6OrientationSensor", AllowMultipleInstances = true)]
        ChrUm6OrientationSensorOperations _mainPort = new ChrUm6OrientationSensorOperations();

        [SubscriptionManagerPartner]
        submgr.SubscriptionManagerPort _subMgrPort = new submgr.SubscriptionManagerPort();

        /// <summary>
        /// Communicate with the Chr hardware
        /// </summary>
        private ChrConnection _chrConnection = null;

        /// <summary>
        /// A CCR port for receiving Chr data
        /// </summary>
        private ChrDataPort _chrDataPort = new ChrDataPort();

        /// <summary>
        /// Http helpers
        /// </summary>
        private DsspHttpUtilitiesPort _httpUtilities = new DsspHttpUtilitiesPort();

        /// <summary>
        /// Service Default constructor
        /// </summary>
        public ChrUm6OrientationSensorService(DsspServiceCreationPort creationPort)
            : base(creationPort)
        {
        }

        /// <summary>
        /// Service start
        /// </summary>
        protected override void Start()
        {
            if (_state == null)
            {
                _state = new ChrUm6OrientationSensorState();
                _state.ChrUm6OrientationSensorConfig = new ChrUm6OrientationSensorConfig();
                _state.ChrUm6OrientationSensorConfig.CommPort = 0;

                SaveState(_state);
            }
            else
            {
                // Clear old Chr readings
                _state.GpRmc = null;

            }

            _httpUtilities = DsspHttpUtilitiesService.Create(Environment);

            if (_state.ChrUm6OrientationSensorConfig == null)
                _state.ChrUm6OrientationSensorConfig = new ChrUm6OrientationSensorConfig();


            // Publish the service to the local Node Directory
            DirectoryInsert();

            _chrConnection = new ChrConnection(_state.ChrUm6OrientationSensorConfig, _chrDataPort);

            SpawnIterator(ConnectToChrUm6OrientationSensor);

            // Listen on the main port for requests and call the appropriate handler.
            Interleave mainInterleave = ActivateDsspOperationHandlers();

            mainInterleave.CombineWith(new Interleave(new ExclusiveReceiverGroup(
                Arbiter.Receive<string[]>(true, _chrDataPort, DataReceivedHandler),
                Arbiter.Receive<Exception>(true, _chrDataPort, ExceptionHandler),
                Arbiter.Receive<string>(true, _chrDataPort, MessageHandler)
                ),
                new ConcurrentReceiverGroup()));


            //base.Start(); -- can't have it here, we already started mainInterleave and added to directory via DirectoryInsert
        }

        #region Service Handlers

        /// <summary>
        /// Handle Errors
        /// </summary>
        /// <param name="ex"></param>
        private void ExceptionHandler(Exception ex)
        {
            LogError(ex.Message);
        }

        /// <summary>
        /// Handle messages
        /// </summary>
        /// <param name="message"></param>
        private void MessageHandler(string message)
        {
            LogInfo(message);
        }

        /// <summary>
        /// Handle inbound Chr Data
        /// </summary>
        /// <param name="fields"></param>
        private void DataReceivedHandler(string[] fields)
        {
            if (fields[0].Equals("$GPRMC"))
                RmcHandler(fields);
            // more handlers here as needed
            else
            {
                string line = string.Join(",", fields);
                MessageHandler(Resources.UnhandledChrData + line);
            }
        }

        /// <summary>
        /// Handle Chr GPRMC data packet
        /// </summary>
        /// <param name="fields"></param>
        private void RmcHandler(string[] fields)
        {
            try
            {
                if (_state.GpRmc == null)
                    _state.GpRmc = new GpRmc();

                _state.GpRmc.IsValid = false;

                if (fields.Length < 11 || fields.Length > 13)
                {
                    MessageHandler(string.Format(CultureInfo.InvariantCulture, "Invalid Number of parameters in GPRMC ({0}/{1})", fields.Length, 12));
                    return;
                }

                string UtcTime = fields[1];
                string Status = fields[2];   // V

                string latitude = fields[3];
                string northSouth = fields[4];
                string longitude = fields[5];
                string eastWest = fields[6];
                double speedKnots = double.Parse(fields[7], CultureInfo.InvariantCulture);
                string courseDegrees = fields[8];
                string dateDDMMYY = fields[9];                           //120120 is bad data
                // string magneticVariationDegrees = fields[10];

                _state.GpRmc.LastUpdate = DateTime.Now;
                _state.GpRmc.Status = Status;
                _state.GpRmc.Latitude = ParseLatitude(latitude, northSouth);
                _state.GpRmc.Longitude = ParseLongitude(longitude, eastWest);
                if (IsNumericDouble(courseDegrees))
                    _state.GpRmc.CourseDegrees = double.Parse(courseDegrees, CultureInfo.InvariantCulture);
                _state.GpRmc.DateTime = ParseUTCDateTime(dateDDMMYY, UtcTime);  // hhmmss.sss

                // Validate!
                _state.GpRmc.IsValid = (Status != "V");

                SendNotification(_subMgrPort, new GpRmcNotification(_state.GpRmc), Tag_GpRmc, _state.GpRmc.IsValid.ToString());

            }
            catch (Exception ex)
            {
                _chrDataPort.Post(ex);
            }
        }

        #endregion

        #region Operation Handlers

        /// <summary>
        /// Http Get Handler
        /// </summary>
        /// <param name="httpGet"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Concurrent)]
        public virtual IEnumerator<ITask> HttpGetHandler(HttpGet httpGet)
        {
            HttpListenerRequest request = httpGet.Body.Context.Request;
            HttpListenerResponse response = httpGet.Body.Context.Response;

            HttpResponseType rsp = null;

            string path = request.Url.AbsolutePath.ToLowerInvariant();

            rsp = new HttpResponseType(HttpStatusCode.OK, _state, _transformChrData);
            httpGet.ResponsePort.Post(rsp);
            yield break;

        }

        /// <summary>
        /// Http Post Handler
        /// </summary>
        /// <param name="httpPost"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Exclusive)]
        public IEnumerator<ITask> HttpPostHandler(HttpPost httpPost)
        {
            // Use helper to read form data
            ReadFormData readForm = new ReadFormData(httpPost);
            _httpUtilities.Post(readForm);

            // Wait for result
            Activate(Arbiter.Choice(readForm.ResultPort,
                delegate(NameValueCollection parameters)
                {
                    if (!string.IsNullOrEmpty(parameters["Action"])
                        && parameters["Action"] == "ChrUm6OrientationSensorConfig"
                        )
                    {
                        if (parameters["buttonOk"] == "Search")
                        {
                            FindChrConfig findConfig = new FindChrConfig();
                            _mainPort.Post(findConfig);
                            Activate(
                                Arbiter.Choice(
                                    Arbiter.Receive<ChrUm6OrientationSensorConfig>(false, findConfig.ResponsePort,
                                        delegate(ChrUm6OrientationSensorConfig response)
                                        {
                                            HttpPostSuccess(httpPost);
                                        }),
                                    Arbiter.Receive<Fault>(false, findConfig.ResponsePort,
                                        delegate(Fault f)
                                        {
                                            HttpPostFailure(httpPost, f);
                                        })
                                )
                            );

                        }
                        else if (parameters["buttonOk"] == "Connect")
                        {

                            ChrUm6OrientationSensorConfig config = (ChrUm6OrientationSensorConfig)_state.ChrUm6OrientationSensorConfig.Clone();
                            int port;
                            if (int.TryParse(parameters["CommPort"], out port) && port >= 0)
                            {
                                config.CommPort = port;
                                config.PortName = "COM" + port.ToString();
                            }

                            int baud;
                            if (int.TryParse(parameters["BaudRate"], out baud) && ChrConnection.ValidBaudRate(baud))
                            {
                                config.BaudRate = baud;
                            }

                            Configure configure = new Configure(config);
                            _mainPort.Post(configure);
                            Activate(
                                Arbiter.Choice(
                                    Arbiter.Receive<DefaultUpdateResponseType>(false, configure.ResponsePort,
                                        delegate(DefaultUpdateResponseType response)
                                        {
                                            HttpPostSuccess(httpPost);
                                        }),
                                    Arbiter.Receive<Fault>(false, configure.ResponsePort,
                                        delegate(Fault f)
                                        {
                                            HttpPostFailure(httpPost, f);
                                        })
                                )
                            );
                        }

                    }
                    else
                    {
                        HttpPostFailure(httpPost, null);
                    }
                },
                delegate(Exception Failure)
                {
                    LogError(Failure.Message);
                })
            );
            yield break;
        }

        /// <summary>
        /// Send Http Post Success Response
        /// </summary>
        /// <param name="httpPost"></param>
        private void HttpPostSuccess(HttpPost httpPost)
        {
            HttpResponseType rsp =
                new HttpResponseType(HttpStatusCode.OK, _state, _transformChrData);
            httpPost.ResponsePort.Post(rsp);
        }

        /// <summary>
        /// Send Http Post Failure Response
        /// </summary>
        /// <param name="httpPost"></param>
        /// <param name="fault"></param>
        private static void HttpPostFailure(HttpPost httpPost, Fault fault)
        {
            HttpResponseType rsp =
                new HttpResponseType(HttpStatusCode.BadRequest, fault);
            httpPost.ResponsePort.Post(rsp);
        }


        /// <summary>
        /// Get Handler
        /// </summary>
        /// <param name="get"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Concurrent)]
        public virtual IEnumerator<ITask> GetHandler(Get get)
        {
            get.ResponsePort.Post(_state);
            yield break;
        }

        /// <summary>
        /// Configure Handler
        /// </summary>
        /// <param name="update"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Exclusive)]
        public virtual IEnumerator<ITask> ConfigureHandler(Configure update)
        {
            _state.ChrUm6OrientationSensorConfig = update.Body;
            bool connected = _chrConnection.Open(_state.ChrUm6OrientationSensorConfig.CommPort, _state.ChrUm6OrientationSensorConfig.BaudRate);

            SaveState(_state);
            update.ResponsePort.Post(DefaultUpdateResponseType.Instance);
            yield break;
        }

        /// <summary>
        /// Subscribe Handler
        /// </summary>
        /// <param name="subscribe"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Exclusive)]
        public virtual IEnumerator<ITask> SubscribeHandler(Subscribe subscribe)
        {
            SubscribeRequest request = subscribe.Body;

            submgr.InsertSubscription insert = new submgr.InsertSubscription(request);
            insert.Body.FilterType = submgr.FilterType.Default;

            string valid = request.ValidOnly ? "True" : null;

            List<submgr.QueryType> query = new List<submgr.QueryType>();

            if (request.MessageTypes == ChrMessageType.All ||
                request.MessageTypes == ChrMessageType.None)
            {
                if (request.ValidOnly)
                {
                    query.Add(new submgr.QueryType(null, valid));
                }
            }
            else
            {
                if ((request.MessageTypes & ChrMessageType.GPRMC) != 0)
                {
                    query.Add(new submgr.QueryType(Tag_GpRmc, valid));
                }
                // add more types here to the query
            }

            if (query.Count > 0)
            {
                insert.Body.QueryList = query.ToArray();
            }
            _subMgrPort.Post(insert);

            yield return Arbiter.Choice(
                insert.ResponsePort,
                subscribe.ResponsePort.Post,
                subscribe.ResponsePort.Post
            );
        }

        /// <summary>
        /// Find a CHR UM6 Sensor on any serial port
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Exclusive)]
        public virtual IEnumerator<ITask> FindChrConfigHandler(FindChrConfig query)
        {
            _state.Connected = _chrConnection.FindChr();
            if (_state.Connected)
            {
                _state.ChrUm6OrientationSensorConfig = _chrConnection.ChrUm6OrientationSensorConfig;
                SaveState(_state);
            }
            query.ResponsePort.Post(_state.ChrUm6OrientationSensorConfig);
            yield break;
        }



        /// <summary>
        /// SendChrCommand Handler
        /// </summary>
        /// <param name="update"></param>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Exclusive)]
        public virtual IEnumerator<ITask> SendChrCommandHandler(SendChrUm6OrientationSensorCommand update)
        {
            update.ResponsePort.Post(
                Fault.FromException(
                    new NotImplementedException("The CHR UM6 Sensor service is a sample. Sending commands to the sensor is an exercise left to the community.")));

            yield break;
        }

        /// <summary>
        /// Shut down the CHR UM6 Sensor connection
        /// </summary>
        /// <returns></returns>
        [ServiceHandler(ServiceHandlerBehavior.Teardown)]
        public virtual IEnumerator<ITask> DropHandler(DsspDefaultDrop drop)
        {
            if (_state.Connected)
            {
                _chrConnection.Close();
                _state.Connected = false;
            }

            base.DefaultDropHandler(drop);
            yield break;
        }

        #endregion

        #region Chr Helpers

        /// <summary>
        /// Connect to a CHR UM6 Sensor.
        /// If no configuration exists, search for the connection.
        /// </summary>
        private IEnumerator<ITask> ConnectToChrUm6OrientationSensor()
        {
            try
            {
                _state.GpRmc = null;
                _state.Connected = false;

                if (_state.ChrUm6OrientationSensorConfig.CommPort != 0 && _state.ChrUm6OrientationSensorConfig.BaudRate != 0)
                {
                    _state.ChrUm6OrientationSensorConfig.ConfigurationStatus = "Opening Chr on Port " + _state.ChrUm6OrientationSensorConfig.CommPort.ToString();
                    _state.Connected = _chrConnection.Open(_state.ChrUm6OrientationSensorConfig.CommPort, _state.ChrUm6OrientationSensorConfig.BaudRate);
                }
                else if (File.Exists(_state.ChrUm6OrientationSensorConfig.PortName))
                {
                    _state.ChrUm6OrientationSensorConfig.ConfigurationStatus = "Opening Chr on " + _state.ChrUm6OrientationSensorConfig.PortName;
                    _state.Connected = _chrConnection.Open(_state.ChrUm6OrientationSensorConfig.PortName);
                }
                else
                {
                    _state.ChrUm6OrientationSensorConfig.ConfigurationStatus = "Searching for the CH Robotics UM6 Orientation Sensor Port";
                    _state.Connected = _chrConnection.FindChr();
                    if (_state.Connected)
                    {
                        _state.ChrUm6OrientationSensorConfig = _chrConnection.ChrUm6OrientationSensorConfig;
                        SaveState(_state);
                    }
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                LogError(ex);
            }
            catch (IOException ex)
            {
                LogError(ex);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                LogError(ex);
            }
            catch (ArgumentException ex)
            {
                LogError(ex);
            }
            catch (InvalidOperationException ex)
            {
                LogError(ex);
            }

            if (!_state.Connected)
            {
                _state.ChrUm6OrientationSensorConfig.ConfigurationStatus = "Not Connected";
                LogInfo(LogGroups.Console, "The CH Robotics UM6 Orientation Sensor is not detected.\r\n*   To configure the CHR UM6 Sensor, navigate to: ");
            }
            else
            {
                _state.ChrUm6OrientationSensorConfig.ConfigurationStatus = "Connected";
            }
            yield break;
        }

        /// <summary>
        /// True when the specified string is a valid double
        /// </summary>
        /// <param name="numeric"></param>
        /// <returns></returns>
        public static bool IsNumericDouble(string numeric)
        {
            if (string.IsNullOrEmpty(numeric))
                return false;

            bool decimalFound = false;
            numeric = numeric.Trim();
            if (numeric.StartsWith("+", StringComparison.Ordinal) || numeric.StartsWith("-", StringComparison.Ordinal))
                numeric = numeric.Substring(1);

            if (numeric.Length == 0)
                return false;

            foreach (char c in numeric)
            {
                if (c >= '0' && c <= '9')
                    continue;
                if ((c == '.') && !decimalFound)
                {
                    decimalFound = true;
                    continue;
                }
                return false;
            }
            return true;
        }

        /// <summary>
        /// Parse Chr Latitude
        /// </summary>
        /// <param name="Latitude"></param>
        /// <param name="NorthSouth"></param>
        /// <returns></returns>
        private static double ParseLatitude(string Latitude, string NorthSouth)
        {
            // LATITUDE
            bool IsNorth = (NorthSouth != "S");
            double degrees = Double.Parse(Latitude.Substring(0, 2), CultureInfo.InvariantCulture);
            double minutes = Double.Parse(Latitude.Substring(2), CultureInfo.InvariantCulture);
            double dLatitude = degrees + minutes / 60.0;
            if (!IsNorth)
            {
                dLatitude = -dLatitude;
            }

            return dLatitude;
        }

        /// <summary>
        /// Parse Chr Longitude
        /// </summary>
        /// <param name="Longitude"></param>
        /// <param name="EastWest"></param>
        /// <returns></returns>
        private static double ParseLongitude(string Longitude, string EastWest)
        {
            // LONGITUDE
            bool IsWest = (EastWest != "E");
            double degrees = Double.Parse(Longitude.Substring(0, 3), CultureInfo.InvariantCulture);
            double minutes = Double.Parse(Longitude.Substring(3), CultureInfo.InvariantCulture);
            double dLongitude = degrees + minutes / 60.0;
            if (IsWest)
            {
                dLongitude = -dLongitude;
            }
            return dLongitude;
        }

        /// <summary>
        /// Parse UTC Date and Time
        /// </summary>
        /// <param name="DateDDMMYY"></param>
        /// <param name="UTCPosition"></param>
        /// <returns></returns>
        private static DateTime ParseUTCDateTime(string DateDDMMYY, string UTCPosition)
        {
            DateTime date = DateTime.Now.Date;
            if (DateDDMMYY.Length > 0)
            {
                string DateMMDDYY = string.Format(CultureInfo.InvariantCulture, "{0}/{1}/{2}", DateDDMMYY.Substring(2, 2), DateDDMMYY.Substring(0, 2), DateDDMMYY.Substring(4, 2));
                date = System.Convert.ToDateTime(DateMMDDYY, CultureInfo.InvariantCulture).Date;
            }

            // hhmmss.sss
            int hh = int.Parse(UTCPosition.Substring(0, 2), CultureInfo.InvariantCulture);
            int mm = int.Parse(UTCPosition.Substring(2, 2), CultureInfo.InvariantCulture);
            int ss = int.Parse(UTCPosition.Substring(4, 2), CultureInfo.InvariantCulture);
            int ms = int.Parse(UTCPosition.Substring(7), CultureInfo.InvariantCulture);
            DateTime Utc = new DateTime(date.Year, date.Month, date.Day, hh, mm, ss, ms);
            DateTime adjustedDate = Utc.ToLocalTime();
            return adjustedDate;
        }

        /// <summary>
        /// Parse UTC Time
        /// </summary>
        /// <param name="UTCPosition"></param>
        /// <returns></returns>
        private static TimeSpan ParseUTCTime(string UTCPosition)
        {
            if (UTCPosition.Length < 8)
                return TimeSpan.MinValue;

            // hhmmss.sss
            int hh = int.Parse(UTCPosition.Substring(0, 2), CultureInfo.InvariantCulture);
            int mm = int.Parse(UTCPosition.Substring(2, 2), CultureInfo.InvariantCulture);
            int ss = int.Parse(UTCPosition.Substring(4, 2), CultureInfo.InvariantCulture);
            int ms = int.Parse(UTCPosition.Substring(7), CultureInfo.InvariantCulture);

            DateTime date = DateTime.Now.Date;
            DateTime Utc = new DateTime(date.Year, date.Month, date.Day, hh, mm, ss, ms);
            DateTime adjustedDate = Utc.ToLocalTime();
            TimeSpan time = new TimeSpan(0, adjustedDate.Hour, adjustedDate.Minute, adjustedDate.Second, adjustedDate.Millisecond);
            return time;
        }

        #endregion

    }
}


