using System;
using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Ccr.Core;
using Microsoft.Dss.Core.Attributes;
using Microsoft.Dss.ServiceModel.Dssp;
using Microsoft.Dss.ServiceModel.DsspServiceBase;
using W3C.Soap;

using Microsoft.Dss.Core.DsspHttp;
using System.Diagnostics.CodeAnalysis;

namespace TrackRoamer.Robotics.Hardware.ChrUm6OrientationSensor
{
    /// <summary>
    /// ChrUm6OrientationSensor contract class
    /// </summary>
    public sealed class Contract
    {
        /// <summary>
        /// DSS contract identifer for ChrUm6OrientationSensor
        /// </summary>
        [DataMember]
        public const string Identifier = "http://schemas.trackroamer.com/2011/12/chrum6orientationsensor.html";
    }

    #region Operation Ports

    /// <summary>
    /// ChrUm6OrientationSensor main operations port
    /// </summary>
    [ServicePort]
    public class ChrUm6OrientationSensorOperations : PortSet
    {
        /// <summary>
        /// CHR UM6 Sensor Main Operation Port
        /// </summary>
        public ChrUm6OrientationSensorOperations()
            : base(
                typeof(DsspDefaultLookup),
                typeof(DsspDefaultDrop),
                typeof(Get),
                typeof(Configure),
                typeof(FindChrConfig),
                typeof(Subscribe),
                typeof(SendChrUm6OrientationSensorCommand),
                typeof(HttpGet),
                typeof(HttpPost),
                typeof(GpRmcNotification)
                // more data types here as needed
        ) { }

        #region Implicit Operators

        /// <summary>
        /// Implicit Operator for Port of DsspDefaultLookup
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<DsspDefaultLookup>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<DsspDefaultLookup>)portSet[typeof(DsspDefaultLookup)];
        }
        /// <summary>
        /// Implicit Operator for Port of DsspDefaultDrop
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<DsspDefaultDrop>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<DsspDefaultDrop>)portSet[typeof(DsspDefaultDrop)];
        }
        /// <summary>
        /// Implicit Operator for Port of Get
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<Get>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<Get>)portSet[typeof(Get)];
        }
        /// <summary>
        /// Implicit Operator for Port of Configure
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<Configure>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<Configure>)portSet[typeof(Configure)];
        }
        /// <summary>
        /// Implicit Operator for Port of FindChrConfig
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<FindChrConfig>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<FindChrConfig>)portSet[typeof(FindChrConfig)];
        }
        /// <summary>
        /// Implicit Operator for Port of Subscribe
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<Subscribe>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<Subscribe>)portSet[typeof(Subscribe)];
        }
        /// <summary>
        /// Implicit Operator for Port of SendChrUm6OrientationSensorCommand
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<SendChrUm6OrientationSensorCommand>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<SendChrUm6OrientationSensorCommand>)portSet[typeof(SendChrUm6OrientationSensorCommand)];
        }
        /// <summary>
        /// Implicit Operator for Port of HttpGet
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<HttpGet>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<HttpGet>)portSet[typeof(HttpGet)];
        }
        /// <summary>
        /// Implicit Operator for Port of HttpPost
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<HttpPost>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<HttpPost>)portSet[typeof(HttpPost)];
        }

        /// <summary>
        /// Implicit Operator for Port of GpRmcNotification
        /// </summary>
        /// <param name="portSet"></param>
        /// <returns></returns>
        public static implicit operator Port<GpRmcNotification>(ChrUm6OrientationSensorOperations portSet)
        {
            if (portSet == null) return null;
            return (Port<GpRmcNotification>)portSet[typeof(GpRmcNotification)];
        }

        // other notification operators here as needed

        #endregion

        #region Post Methods

        /// <summary>
        /// Post(DsspDefaultLookup)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(DsspDefaultLookup item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(DsspDefaultDrop)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(DsspDefaultDrop item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(Get)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(Get item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(Configure)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(Configure item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(FindChrConfig)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(FindChrConfig item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(Subscribe)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(Subscribe item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(SendChrUm6OrientationSensorCommand)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(SendChrUm6OrientationSensorCommand item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(HttpGet)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(HttpGet item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(HttpPost)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(HttpPost item) { base.PostUnknownType(item); }
        /// <summary>
        /// Post(GpRmcNotification)
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public void Post(GpRmcNotification item) { base.PostUnknownType(item); }

        // more Post methods here for other data types as needed.

        #endregion

        #region Operation Helpers

        /// <summary>
        /// Required Lookup request body type
        /// </summary>
        public virtual PortSet<LookupResponse, Fault> DsspDefaultLookup()
        {
            LookupRequestType body = new LookupRequestType();
            DsspDefaultLookup op = new DsspDefaultLookup(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Dssp Default Lookup and return the response port.
        /// </summary>
        public virtual PortSet<LookupResponse, Fault> DsspDefaultLookup(LookupRequestType body)
        {
            DsspDefaultLookup op = new DsspDefaultLookup();
            op.Body = body ?? new LookupRequestType();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// A request to drop the service.
        /// </summary>
        public virtual PortSet<DefaultDropResponseType, Fault> DsspDefaultDrop()
        {
            DropRequestType body = new DropRequestType();
            DsspDefaultDrop op = new DsspDefaultDrop(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Dssp Default Drop and return the response port.
        /// </summary>
        public virtual PortSet<DefaultDropResponseType, Fault> DsspDefaultDrop(DropRequestType body)
        {
            DsspDefaultDrop op = new DsspDefaultDrop();
            op.Body = body ?? new DropRequestType();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Required Get body type
        /// </summary>
        public virtual PortSet<ChrUm6OrientationSensorState, Fault> Get()
        {
            GetRequestType body = new GetRequestType();
            Get op = new Get(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Get and return the response port.
        /// </summary>
        public virtual PortSet<ChrUm6OrientationSensorState, Fault> Get(GetRequestType body)
        {
            Get op = new Get();
            op.Body = body ?? new GetRequestType();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// ChrUm6OrientationSensor Serial Port Configuration
        /// </summary>
        public virtual PortSet<DefaultUpdateResponseType, Fault> Configure()
        {
            ChrUm6OrientationSensorConfig body = new ChrUm6OrientationSensorConfig();
            Configure op = new Configure(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Configure and return the response port.
        /// </summary>
        public virtual PortSet<DefaultUpdateResponseType, Fault> Configure(ChrUm6OrientationSensorConfig body)
        {
            Configure op = new Configure();
            op.Body = body ?? new ChrUm6OrientationSensorConfig();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// ChrUm6OrientationSensor Serial Port Configuration
        /// </summary>
        public virtual PortSet<ChrUm6OrientationSensorConfig, Fault> FindChrConfig()
        {
            ChrUm6OrientationSensorConfig body = new ChrUm6OrientationSensorConfig();
            FindChrConfig op = new FindChrConfig(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Find Chr Config and return the response port.
        /// </summary>
        public virtual PortSet<ChrUm6OrientationSensorConfig, Fault> FindChrConfig(ChrUm6OrientationSensorConfig body)
        {
            FindChrConfig op = new FindChrConfig();
            op.Body = body ?? new ChrUm6OrientationSensorConfig();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Subscribe and return the response port.
        /// </summary>
        public virtual PortSet<SubscribeResponseType, Fault> Subscribe(IPort notificationPort)
        {
            Subscribe op = new Subscribe();
            op.Body = new SubscribeRequest();
            op.NotificationPort = notificationPort;
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Subscribe and return the response port.
        /// </summary>
        public virtual PortSet<SubscribeResponseType, Fault> Subscribe(SubscribeRequest body, IPort notificationPort)
        {
            Subscribe op = new Subscribe();
            op.Body = body ?? new SubscribeRequest();
            op.NotificationPort = notificationPort;
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// A CHR UM6 Sensor Command
        /// <remarks>Use with SendChrUm6OrientationSensorCommand()</remarks></summary>
        public virtual PortSet<DefaultUpdateResponseType, Fault> SendChrUm6OrientationSensorCommand()
        {
            ChrUm6OrientationSensorCommand body = new ChrUm6OrientationSensorCommand();
            SendChrUm6OrientationSensorCommand op = new SendChrUm6OrientationSensorCommand(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Send CHR UM6 Sensor Command and return the response port.
        /// </summary>
        public virtual PortSet<DefaultUpdateResponseType, Fault> SendChrUm6OrientationSensorCommand(ChrUm6OrientationSensorCommand body)
        {
            SendChrUm6OrientationSensorCommand op = new SendChrUm6OrientationSensorCommand();
            op.Body = body ?? new ChrUm6OrientationSensorCommand();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// DsspHttp Get request body
        /// </summary>
        public virtual PortSet<HttpResponseType, Fault> HttpGet()
        {
            HttpGetRequestType body = new HttpGetRequestType();
            HttpGet op = new HttpGet(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Http Get and return the response port.
        /// </summary>
        public virtual PortSet<HttpResponseType, Fault> HttpGet(HttpGetRequestType body)
        {
            HttpGet op = new HttpGet();
            op.Body = body ?? new HttpGetRequestType();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// DsspHttp Post request body
        /// </summary>
        public virtual PortSet<HttpResponseType, Fault> HttpPost()
        {
            HttpPostRequestType body = new HttpPostRequestType();
            HttpPost op = new HttpPost(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Http Post and return the response port.
        /// </summary>
        public virtual PortSet<HttpResponseType, Fault> HttpPost(HttpPostRequestType body)
        {
            HttpPost op = new HttpPost();
            op.Body = body ?? new HttpPostRequestType();
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Time, date, position, course and speed data
        /// </summary>
        public virtual DsspResponsePort<DefaultUpdateResponseType> GpRmcNotification()
        {
            GpRmc body = new GpRmc();
            GpRmcNotification op = new GpRmcNotification(body);
            this.Post(op);
            return op.ResponsePort;

        }
        /// <summary>
        /// Post Gp Rmc Notification and return the response port.
        /// </summary>
        public virtual DsspResponsePort<DefaultUpdateResponseType> GpRmcNotification(GpRmc body)
        {
            GpRmcNotification op = new GpRmcNotification();
            op.Body = body ?? new GpRmc();
            this.Post(op);
            return op.ResponsePort;

        }

        // more data types here as needed

        #endregion
    }

    /// <summary>
    /// Gets the current state of the CH Robotics UM6 Orientation Sensor - get operation
    /// </summary>
#if DEBUG
    [SuppressMessage("Microsoft.Naming", "CA1716", Justification="Get is a Dss reserved word.")]
#endif
    [DisplayName("(User) Get")]
    [Description("Gets the current state of the CH Robotics UM6 Orientation Sensor.")]
    public class Get : Get<GetRequestType, PortSet<ChrUm6OrientationSensorState, Fault>>
    {
        /// <summary>
        /// Creates a new instance of Get
        /// </summary>
        public Get()
        {
        }

        /// <summary>
        /// Creates a new instance of Get
        /// </summary>
        /// <param name="body">the request message body</param>
        public Get(GetRequestType body)
            : base(body)
        {
        }

        /// <summary>
        /// Creates a new instance of Get
        /// </summary>
        /// <param name="body">the request message body</param>
        /// <param name="responsePort">the response port for the request</param>
        public Get(GetRequestType body, PortSet<ChrUm6OrientationSensorState, Fault> responsePort)
            : base(body, responsePort)
        {
        }
    }

    /// <summary>
    /// Configure CHR UM6 Sensor Operation
    /// </summary>
    [DisplayName("(User) Configure")]
    [Description("Configures a CH Robotics UM6 Orientation Sensor.")]
    public class Configure : Update<ChrUm6OrientationSensorConfig, PortSet<DefaultUpdateResponseType, Fault>>
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public Configure() { }
        /// <summary>
        /// Initialization Constructor
        /// </summary>
        /// <param name="config"></param>
        public Configure(ChrUm6OrientationSensorConfig config)
        {
            this.Body = config;
        }
    }

    /// <summary>
    /// ChrUm6OrientationSensor subscribe operation
    /// </summary>
    public class Subscribe : Subscribe<SubscribeRequest, PortSet<SubscribeResponseType, Fault>, ChrUm6OrientationSensorOperations>
    {
        /// <summary>
        /// Creates a new instance of Subscribe
        /// </summary>
        public Subscribe()
        {
        }

        /// <summary>
        /// Creates a new instance of Subscribe
        /// </summary>
        /// <param name="body">the request message body</param>
        public Subscribe(SubscribeRequest body)
            : base(body)
        {
        }

        /// <summary>
        /// Creates a new instance of Subscribe
        /// </summary>
        /// <param name="body">the request message body</param>
        /// <param name="responsePort">the response port for the request</param>
        public Subscribe(SubscribeRequest body, PortSet<SubscribeResponseType, Fault> responsePort)
            : base(body, responsePort)
        {
        }
    }

    /// <summary>
    /// Finds and configures an installed CHR UM6 Sensor device.
    /// </summary>
    [DisplayName("(User) Find CH Robotics UM6 Orientation Sensor")]
    [Description("Finds and configures an installed CH Robotics UM6 Orientation Sensor.")]
    public class FindChrConfig : Query<ChrUm6OrientationSensorConfig, PortSet<ChrUm6OrientationSensorConfig, Fault>>
    {
        /// <summary>
        /// Finds and configures an installed CHR UM6 Sensor.
        /// </summary>
        public FindChrConfig()
        {
        }

        /// <summary>
        /// Finds and configures an installed CHR UM6 Sensor.
        /// </summary>
        /// <param name="body"></param>
        public FindChrConfig(ChrUm6OrientationSensorConfig body)
            : base(body)
        {
        }

        /// <summary>
        /// Finds and configures an installed CHR UM6 Sensor.
        /// </summary>
        /// <param name="body"></param>
        /// <param name="responsePort"></param>
        public FindChrConfig(ChrUm6OrientationSensorConfig body, Microsoft.Ccr.Core.PortSet<ChrUm6OrientationSensorConfig, W3C.Soap.Fault> responsePort)
            : base(body, responsePort)
        {
        }
    }


    /// <summary>
    /// Sends a command to the CHR UM6 Sensor.
    /// </summary>
    [DisplayName("(User) Send CHR UM6 Sensor Command")]
    [Description("Sends a command to the CHR UM6 Sensor.")]
    public class SendChrUm6OrientationSensorCommand : Update<ChrUm6OrientationSensorCommand, PortSet<DefaultUpdateResponseType, Fault>>
    {
        /// <summary>
        /// Sends a command to the CHR UM6 Sensor.
        /// </summary>
        public SendChrUm6OrientationSensorCommand()
        {
        }

        /// <summary>
        /// Sends a command to the CHR UM6 Sensor.
        /// </summary>
        /// <param name="body"></param>
        public SendChrUm6OrientationSensorCommand(ChrUm6OrientationSensorCommand body)
            :
                base(body)
        {
        }

        /// <summary>
        /// Sends a command to the CHR UM6 Sensor.
        /// </summary>
        /// <param name="body"></param>
        /// <param name="responsePort"></param>
        public SendChrUm6OrientationSensorCommand(ChrUm6OrientationSensorCommand body, Microsoft.Ccr.Core.PortSet<Microsoft.Dss.ServiceModel.Dssp.DefaultUpdateResponseType, W3C.Soap.Fault> responsePort)
            :
                base(body, responsePort)
        {
        }
    }

    /// <summary>
    /// GPRMC Notification
    /// </summary>
    [DisplayName("(User) UpdateGPRMCData")]
    [Description("Indicates an update of the RMC: Backup course, speed, and position.")]
    public class GpRmcNotification : Update<GpRmc, DsspResponsePort<DefaultUpdateResponseType>>
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        /// <param name="data"></param>
        public GpRmcNotification(GpRmc data) { this.Body = data; }

        /// <summary>
        /// Empty constructor
        /// </summary>
        public GpRmcNotification() { }
    }

    #endregion
}


